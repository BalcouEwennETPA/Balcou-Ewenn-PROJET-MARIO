I brought my wind chimes inside and recorded them with an MXL 910 microphone into my computer using a Focusrite Scarlett 18i20 interface with the gain turned up a bit. I then chopped 15 samples I liked from the entire recording and formatted them into a Make Noise Morphagene reel containing 15 splices.

I am very pleased with the results, especially when patched into Clouds or using an Eventide Space pedal for example.

I've decided to share this reel as royalty free on www.soundpacks.com for other Morphagene users. 

Enjoy,
-Rob

Note: Be sure to rename the reel to mg1 before loading it.